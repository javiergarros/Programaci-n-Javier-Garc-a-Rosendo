public class Libro{
 	private String titulo;
 
 	public String getTitulo(){
 		return titulo;
 	}
 	public void setTitulo(String titulo){
 		this.titulo = titulo;		
 	}
 } 