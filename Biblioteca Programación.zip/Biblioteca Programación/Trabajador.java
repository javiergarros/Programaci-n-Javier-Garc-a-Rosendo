public class Trabajador {
	//Caracteristicas
	private String enfermedades;
	private String alergias;
	private String situacionMarital;
	private String antiguedad;
	private String gustosLectura;
	private String idTrabajador;

	//Metodos 
	public String getEnfermedades() {
		return enfermedades;
	}

	public void setEnfermedades(String enfermedades){
		this.enfermedades = enfermedades;
	}

	public String getAlergias() {
		return alergias;
	}

	public void setAlergias(String alergias) {
		this.alergias = alergias;
	}

	public String getSituacionMarital() {
		return situacionMarital;
	}

	public void setSituacionMarital(String situacionMarital) {
		this.situacionMarital = situacionMarital;
	}

	public String getAntiguedad(){
		return antiguedad;
	}

	public void setAntiguedad(String antiguedad) {
		this.antiguedad = antiguedad;
	}

	public String getGustosLectura() {
		return gustosLectura;
	}

	public void setGustosLectura(String gustosLectura) {
		this.gustosLectura = gustosLectura;
	}

	public String getIdTrabajador () {
		return idTrabajador;
	}

	public void setIdTrabajador (String idTrabajador) {
		
	}
} 