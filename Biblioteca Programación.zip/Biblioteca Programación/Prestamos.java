public class Prestamos {
	//Caracteristicas
	public String condicion;
	private String usuario;
	private String trabajador;

	//Metodos 
	public String getCondicion(){
		return condicion;
	}

	public void setCondicion(String condicion){
		this.condicion = condicion;

	}

	public String getUsuario(){
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getTrabajador() {
		return trabajador;
	}

	public void setTrabajador(String trabajador) {
		this.trabajador = trabajador;
	}
}