public class Socio extends Persona {
	private String matricula;

	public Socio() {
		
	}

	public Socio(String nombre, String apellidoPaterno, String apellidoMaterno, String email, String matricula){
	
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula){
		this.matricula = matricula;
	}

	public String toString(){
 		String persona = "Nombre = " + getNombre() + " " + getApellidoPaterno() + " " + getApellidoMaterno() + ", Matricula = " + matricula();
 		return persona;
	
}
}