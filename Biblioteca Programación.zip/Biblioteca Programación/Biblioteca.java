public class Biblioteca{
 public static void main(String args[]){
 		//Socio
 
 		Socio socio1 = new Socio("Javier", "García", "Rosendo", "jvi@gmail.com", "ZS150113918");
 
 		String resultado = socio1.toString();
 
 		System.out.println(resultado);
 }
}
