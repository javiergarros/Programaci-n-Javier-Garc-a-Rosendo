public class Matriz {
	//Clases
	private String rfc;
	private String direccionFiscal;

	//Metodos 
	public String getRfc () {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getDireccionFiscal() {
		return direccionFiscal;
	}

	public void getDireccionFiscal(String direccionFiscal){
		this.direccionFiscal = direccionFiscal;
	}

}