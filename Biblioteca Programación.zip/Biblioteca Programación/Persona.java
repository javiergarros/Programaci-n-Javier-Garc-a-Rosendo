public class Persona {
	//Caracteristicas 
	private String nombre;
	private String email;
	private String fechaNacimiento;
	private String apellidoPaterno;
	private String apellidoMaterno;

	//Metodos
	public String toString() {
		String persona = "Nombre = " + nombre  + " " + apellidoMaterno + " " + apellidoMaterno;
		return persona;	
	}

	public String getNombre(){
		return nombre;
	} 
	
	public void setNombre (String nombre){
		this.nombre = nombre;
	}

	public String getEmail(){
		return email;
	}
	
	public void setEmail (String email){
		this.email = email;
	}

	public String getFechaNacimiento () {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento){
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getApellidoPaterno(){
		return apellidoPaterno;
	}

	public void setApellidoPaterno (String apellidoPaterno){
		this.apellidoPaterno = apellidoPaterno;
	} 

	public String getApellidoMaterno(){
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno){
		this.apellidoPaterno = apellidoMaterno;
	}

}